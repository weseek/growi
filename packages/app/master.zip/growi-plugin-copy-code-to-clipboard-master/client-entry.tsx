import { withCopyButton } from './src/CodeWithCopyButton';

declare const growiFacade: any;

const activate = (): void => {
  const { optionsGenerators } = growiFacade.markdownRenderer;

  optionsGenerators.customGenerateViewOptions = (...args: any[]) => {
    const options = optionsGenerators.generateViewOptions(...args);
    const Code = options.components.code;

    // replace
    options.components.code = withCopyButton(Code);

    return options;
  };
};

const deactivate = (): void => {
};

// register activate
if ((window as any).pluginActivators == null) {
  (window as any).pluginActivators = {};
}
(window as any).pluginActivators['growi-plugin-jstest'] = {
  activate,
  deactivate,
};
